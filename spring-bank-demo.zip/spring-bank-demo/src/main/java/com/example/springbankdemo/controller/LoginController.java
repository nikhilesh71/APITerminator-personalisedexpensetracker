package com.example.springbankdemo.controller;

import com.example.springbankdemo.pojo.Account;
import com.example.springbankdemo.pojo.Transaction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.springbankdemo.service.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

@Controller
public class LoginController {
    @RequestMapping(value= "/login", method = RequestMethod.GET)
    public String loginPage(){
        return "login";
    }
    @RequestMapping(value= "/index", method = RequestMethod.GET)
    public String index(){
        return "index";
    }
    @RequestMapping(value= "/login", method = RequestMethod.POST)
    public String welcomePage(ModelMap model, @RequestParam int userId, @RequestParam String password, HttpServletRequest request) throws IOException {
        model.put("userId",userId);
        request.setAttribute("userId",userId);
        userCred u = new userCred();
        Account a = u.verify(userId,password);
        HashMap<String, Integer> map = new HashMap<>();

        if(a != null){
            model.put("name",a.getName());
            map = u.chart(a.getTransaction());
            if (map.containsKey("reward")) {
                int reward = map.get("reward");
                model.put("reward",reward);
                request.setAttribute("rewardTotal",reward);
            }
            request.setAttribute("chart",map);
            request.setAttribute("accountD", (a.getTransaction()));
            return "welcome";
        }
        model.put("errorMsg","Provide the correct userid and password");
        return "login";
    }
    @RequestMapping(value= "/analyse/{userId}/{month}", method = RequestMethod.GET)
    public String analysePage(ModelMap model, @PathVariable("userId") int userId,@PathVariable("month") int month, HttpServletRequest request) throws IOException {
        userCred u = new userCred();
        model.put("userId",userId);

        request.setAttribute("userId",userId);
        Account data = u.analyse(userId, month);
        HashMap<String, Integer> map = new HashMap<>();

        if (data != null) {
            model.put("name", data.getName());
            model.put("name",data.getName());
            map = u.chart(data.getTransaction());
           if (map.containsKey("reward")) {
                int reward = map.get("reward");
                model.put("reward",reward);
               model.put("rewardBlack",Math.round(reward*1.5));
               model.put("rewardRe",Math.round(reward*2));
           }
           request.setAttribute("chart", map);
           request.setAttribute("accountfilter", (data.getTransaction()));
           model.put("num", month);
        }
            return "analyse";

    }
    @RequestMapping(value= "/offer", method = RequestMethod.GET)
    public String analysePage(ModelMap model, HttpServletRequest request) throws IOException {

        return "offer";

    }
}

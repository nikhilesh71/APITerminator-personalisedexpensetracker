package com.example.springbankdemo.service;


import com.example.springbankdemo.pojo.Account;

import java.io.File;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;

class loadData {

    public Account accountData(int userid) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        File file = new File("src/main/resources/"+userid+".json");
        Account account =    objectMapper.readValue(file, Account.class);
        return account;
    }
}
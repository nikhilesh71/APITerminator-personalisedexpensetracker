package com.example.springbankdemo.service;


import com.example.springbankdemo.pojo.Account;
import com.example.springbankdemo.pojo.Transaction;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class userCred {
    private loadData accountData;
    public Account verify(int user, String password) throws IOException {
        HashMap<Integer, String> map = new HashMap<>();
        map.put(12345, "admin");
        map.put(12121, "admin");
        map.put(1122, "admin");
        map.put(2353534, "admin");


        if (map.containsKey(user)) {
            String pass = map.get(user);
            if(pass.equals(password)){
                accountData= new loadData();
                return accountData.accountData(user);
            }
        }
        return null;
    }
    public Account analyse(int user,int mon) throws IOException {
        accountData= new loadData();
        Account account = accountData.accountData(user);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDate now = LocalDate.now();
        LocalDate past = now.minusMonths(mon);
        List<Transaction> tr = account.getTransaction();
        List<Transaction> fil = new ArrayList<>();
        // Account a = new Account();

        for (Transaction transaction : tr) {
            LocalDate ll = LocalDate.parse(transaction.getDate(), dtf);
            if (ll.isAfter(past)) {
                fil.add(transaction);
            }

        }
        account.setTransaction(fil);
        return account;
    }
    public HashMap chart(List<Transaction> list) throws IOException {
        HashMap<String, Integer> map = new HashMap<>();
        List<Transaction> ta = list;

        int t = 0;int s=0; int f=0;int fee=0;int h=0;
        double reward=0;
        for (Transaction transaction : ta) {
            int am = transaction.getAmount();
            reward = reward + Math.floor(am < 100 ? 0 : 0.01 * am);
            if (transaction.getCategory().equals("Travel")) {
                t = t + transaction.getAmount();
                //System.out.println(ta.get(i).getAmount());
            }
            if (transaction.getCategory().equals("Shopping")) {
                s = s + transaction.getAmount();
            }
            if (transaction.getCategory().equals("Food")) {
                f = f + transaction.getAmount();
            }
            if (transaction.getCategory().equals("Fee")) {
                fee = fee + transaction.getAmount();
            }
            if (transaction.getCategory().equals("Health")) {
                h = h + transaction.getAmount();
            }

        }
        int total = t+s+f;
        if (t != 0)
            map.put("Travel", Math.round(t * 100 / total));
        if (s != 0)
        map.put("Shopping",Math.round(s*100/total));
        if (f != 0)
        map.put("Food",Math.round(f*100/total));
        if (fee != 0)
            map.put("Transaction fee",Math.round(f*100/total));
        if (h != 0)
            map.put("Health",Math.round(f*100/total));
        map.put("reward",(int)reward);
        return map;
    }

}

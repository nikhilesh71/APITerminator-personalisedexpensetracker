package com.example.springbankdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.example.springbankdemo")
public class SpringBankDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBankDemoApplication.class, args);
	}

}

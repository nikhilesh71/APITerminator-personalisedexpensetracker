package com.example.springbankdemo;

import com.example.springbankdemo.pojo.Account;
import com.example.springbankdemo.pojo.Transaction;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.lang.NonNull;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Random;

;
public class datetest {
    public static void main(String[] args) throws IOException, ParseException {
//        ObjectMapper objectMapper = new ObjectMapper();
//        File file = new File("src/main/resources/"+1122+".json");
//        Account account =    objectMapper.readValue(file, Account.class);
//        List<Transaction> tr = account.getTransaction();
//        List<Transaction> fil = new ArrayList<>();
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
//        LocalDate now = LocalDate.now();

        Integer i = 10;
        int i1 = (int)i;
//        account.setTransaction(fil);
        System.out.println("------"+i1);


    String arr[]  ={"Zara","Nike","Easy London","British Airways","Booking.com","Airbnb","Uber Eats","New London Cafe"};
        int from = 20, to = 40, multi = 5; Random rand = new Random();
        int min = 2, max = 3;
        for (String s:arr) {
            int n = multi*(Math. round(rand. nextInt((to+multi-from))+from)/multi);
            int randomNum = min + (int)(Math. random() * ((max-min) + 1));
            System.out.println(n+"---"+randomNum+"--"+s);

        }

    }
    public static void dsfd(HttpServletRequest request){
        System.out.println(request.getAttribute("chart"));

    }
}
